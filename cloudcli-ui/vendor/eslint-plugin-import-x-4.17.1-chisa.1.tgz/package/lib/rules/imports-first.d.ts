declare const _default: import("@typescript-eslint/utils/ts-eslint").RuleModule<import("./first.js").MessageId, [(import("./first.js").Options | undefined)?], import("../utils/create-rule.ts").ImportXPluginDocs, import("@typescript-eslint/utils/ts-eslint").RuleListener>;
export default _default;
