export type MessageId = 'default';
declare const _default: import("@typescript-eslint/utils/ts-eslint").RuleModule<"default", [], import("../utils/create-rule.ts").ImportXPluginDocs, import("@typescript-eslint/utils/ts-eslint").RuleListener>;
export default _default;
