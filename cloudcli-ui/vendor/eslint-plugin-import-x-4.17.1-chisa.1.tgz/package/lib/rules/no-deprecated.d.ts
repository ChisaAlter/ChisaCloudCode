declare const _default: import("@typescript-eslint/utils/ts-eslint").RuleModule<"deprecated" | "deprecatedDesc", [], import("../utils/create-rule.ts").ImportXPluginDocs, import("@typescript-eslint/utils/ts-eslint").RuleListener>;
export default _default;
